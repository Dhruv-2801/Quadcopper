#!/bin/bash
# Boots the whole system in a tmux session: dashboard, transcriber, and writer
# each get their own window, so their output doesn't interleave and you can
# see exactly which piece is doing what.
#
# Always runs as root (re-execs itself with sudo if needed), so it works the
# same regardless of which user account (as long as it has sudo) starts it,
# and file ownership from a previous run never blocks the next one. Attach
# with: sudo tmux attach -t forceplates
#
# Usage:
#   ./start.sh            real ESP32 hardware over serial
#   ./start.sh --sim      simulated plate data, no hardware needed
#   ./start.sh --stop     stop everything
#   ./start.sh --status   show whether it's running
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  exec sudo "$0" "$@"
fi

cd "$(dirname "$0")"

SESSION="forceplates"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8080}"
FORCEPIPE="/tmp/forcepipe"
# Explicit (not just relying on each script's own default) so the dashboard,
# writer, and transcriber can never silently disagree on which DB file to use.
FORCEPLATE_DB="${FORCEPLATE_DB:-$(pwd)/data/forceplate.db}"

# Automatic cow-session detection settings. Override before starting, for example:
# COW_SESSION_THRESHOLD_LBS=120 COW_SESSION_START_DELAY_S=3 bash ./start.sh
COW_SESSION_THRESHOLD_LBS="${COW_SESSION_THRESHOLD_LBS:-100}"
COW_SESSION_START_DELAY_S="${COW_SESSION_START_DELAY_S:-5}"
COW_SESSION_STOP_DELAY_S="${COW_SESSION_STOP_DELAY_S:-5}"
ACTIVE_PLATE_STALE_S="${ACTIVE_PLATE_STALE_S:-2}"

if ! command -v tmux >/dev/null 2>&1; then
  echo "tmux is required but not installed. Install it with: sudo apt install tmux"
  exit 1
fi

chown -R root:dialout data logs 2>/dev/null || true

if [[ "${1:-}" == "--stop" ]]; then
  if tmux has-session -t "$SESSION" 2>/dev/null; then
    tmux kill-session -t "$SESSION"
    rm -f "$FORCEPIPE"
    echo "Stopped."
  else
    echo "Not running."
  fi
  exit 0
fi

if [[ "${1:-}" == "--status" ]]; then
  if tmux has-session -t "$SESSION" 2>/dev/null; then
    echo "Running. Windows: $(tmux list-windows -t "$SESSION" -F '#{window_name}' | tr '\n' ' ')"
    echo "Attach with: sudo tmux attach -t $SESSION"
  else
    echo "Not running."
  fi
  exit 0
fi

if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "Already running. Attach with: sudo tmux attach -t $SESSION"
  echo "(or stop it first: ./start.sh --stop)"
  exit 1
fi

MODE="hardware"
if [[ "${1:-}" == "--sim" ]]; then
  MODE="sim"
fi

check_port_free() {
  # A connect probe (not bind) so a just-freed port in TIME_WAIT doesn't false-positive -
  # server.py sets SO_REUSEADDR and would bind fine even then.
  if python3 -c "
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(1)
result = s.connect_ex(('${HOST}', ${PORT}))
s.close()
raise SystemExit(0 if result == 0 else 1)
"; then
    echo "Port ${PORT} is already in use - something else is already listening there."
    echo "Find it with: sudo lsof -i:${PORT}"
    exit 1
  fi
}

check_port_free

tmux new-session -d -s "$SESSION" -n dashboard \
  "FORCEPLATE_DB='$FORCEPLATE_DB' python3 server.py; echo; echo '[dashboard exited - press enter to close]'; read -r"

if [[ "$MODE" == "sim" ]]; then
  echo "Plates: using simulated data, no hardware needed."
  tmux new-window -t "$SESSION" -n plates \
    "python3 sim_forceplates.py | FORCEPLATE_DB='$FORCEPLATE_DB' COW_SESSION_THRESHOLD_LBS='$COW_SESSION_THRESHOLD_LBS' COW_SESSION_START_DELAY_S='$COW_SESSION_START_DELAY_S' COW_SESSION_STOP_DELAY_S='$COW_SESSION_STOP_DELAY_S' ACTIVE_PLATE_STALE_S='$ACTIVE_PLATE_STALE_S' python3 forceplate_writer.py; echo; echo '[plates exited - press enter to close]'; read -r"
else
  echo "Plates: initializing, watching for ESP32 boards over serial..."
  rm -f "$FORCEPIPE"
  mkfifo "$FORCEPIPE"
  chmod 666 "$FORCEPIPE"
  tmux new-window -t "$SESSION" -n writer \
    "FORCEPLATE_DB='$FORCEPLATE_DB' COW_SESSION_THRESHOLD_LBS='$COW_SESSION_THRESHOLD_LBS' COW_SESSION_START_DELAY_S='$COW_SESSION_START_DELAY_S' COW_SESSION_STOP_DELAY_S='$COW_SESSION_STOP_DELAY_S' ACTIVE_PLATE_STALE_S='$ACTIVE_PLATE_STALE_S' python3 forceplate_writer.py < '$FORCEPIPE'; echo; echo '[writer exited - press enter to close]'; read -r"
  tmux new-window -t "$SESSION" -n transcriber \
    "FORCEPLATE_DB='$FORCEPLATE_DB' python3 forceplate_transcriber.py > '$FORCEPIPE'; echo; echo '[transcriber exited - press enter to close]'; read -r"
fi

echo "Started in tmux session '$SESSION'."
echo "Watch live output: sudo tmux attach -t $SESSION   (switch windows: Ctrl-b then a number; detach: Ctrl-b d)"
echo "Stop everything:   ./start.sh --stop"

echo "Dashboard: starting..."
ready=0
for _ in $(seq 1 20); do
  if python3 -c "
import urllib.request
urllib.request.urlopen('http://${HOST}:${PORT}/api/health', timeout=1)
" >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 0.5
done

if [[ "$ready" == "1" ]]; then
  echo "Dashboard is ready! Open http://${HOST}:${PORT} in your browser."
else
  echo "Dashboard is taking longer than expected - attach and check the dashboard window."
fi
