# LameScore automatic cow-session upgrade

Replace the following files in the repository:

- `start.sh`
- `server.py`
- `forceplate_writer.py`
- `static/index.html`
- `static/app.js`
- `static/styles.css`

`forceplate_transcriber.py` is included unchanged for convenience.

Start exactly as before:

```bash
chmod +x start.sh
bash ./start.sh
```

No additional process or command is required. `start.sh` starts `server.py`, the writer, and the transcriber in tmux. The session detector runs inside `forceplate_writer.py`.

Defaults:

- Start when combined live load stays above 100 lb for 5 seconds.
- Stop when combined live load stays below 100 lb for 5 seconds.
- A plate reading is considered live for 2 seconds.

Optional override example:

```bash
COW_SESSION_THRESHOLD_LBS=120 COW_SESSION_START_DELAY_S=3 COW_SESSION_STOP_DELAY_S=5 bash ./start.sh
```

SQLite schema additions:

```sql
CREATE TABLE cow_session (
  cow_id INTEGER PRIMARY KEY AUTOINCREMENT,
  start_time INTEGER NOT NULL,
  stop_time INTEGER
);

ALTER TABLE measurements ADD COLUMN cow_id INTEGER REFERENCES cow_session(cow_id);
```

API endpoints:

- `GET /api/session/active`
- `GET /api/sessions?limit=100`

Test without ESP32 hardware:

```bash
bash ./start.sh --sim
```
