#!/usr/bin/env python3
import json
import hashlib
import hmac
import os
import secrets
import sqlite3
import statistics
import tempfile
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from plate_naming import read_recent_rejects
from device_status import read_status as read_device_status


APP_DIR = Path(__file__).resolve().parent
STATIC_DIR = APP_DIR / "static"
DEFAULT_DB = APP_DIR / "data" / "forceplate.db"
DB_PATH = Path(os.environ.get("FORCEPLATE_DB", DEFAULT_DB)).expanduser()
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
DEFAULT_ADMIN_PASSWORD_HASH = (
    "pbkdf2_sha256$260000$6c616d6573636f72652d64656661756c742d73616c74$"
    "38862f8addb925211b2e0af2814b94799be78343405a9c9e81a46319e737f1eb"
)
ADMIN_PASSWORD_HASH = os.environ.get("ADMIN_PASSWORD_HASH", DEFAULT_ADMIN_PASSWORD_HASH)
ADMIN_SESSIONS = set()

LEG_MAP = {
    "fl": ("frontLeft", "Front left"),
    "fr": ("frontRight", "Front right"),
    "hl": ("backLeft", "Back left"),
    "hr": ("backRight", "Back right"),
}

PLATE_SUFFIXES = {
    "flo", "fli", "flm", "flb",
    "fro", "fri", "frm", "frb",
    "hlo", "hli", "hlm", "hlb",
    "hro", "hri", "hrm", "hrb",
}
GRAMS_PER_LB = 453.59237
SESSION_WINDOW_MS = 8 * 60 * 1000
DEVICE_CONFLICT_WINDOW_MS = 60 * 1000


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=2.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def ensure_app_tables(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tare_offsets (
          set_id        TEXT NOT NULL,
          plate         TEXT NOT NULL,
          offset_lbs    REAL NOT NULL,
          created_ms    INTEGER NOT NULL,
          PRIMARY KEY (set_id, plate)
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS cow_sessions (
          set_id          TEXT PRIMARY KEY,
          session_start_ms INTEGER NOT NULL,
          updated_ms       INTEGER NOT NULL
        )
        """
    )
    # Automatically detected visits. This table is intentionally singular to
    # remain separate from the older per-set dashboard reset table above.
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS cow_session (
          cow_id      INTEGER PRIMARY KEY AUTOINCREMENT,
          start_time  INTEGER NOT NULL,
          stop_time   INTEGER
        )
        """
    )
    columns = {row[1] for row in conn.execute("PRAGMA table_info(measurements)").fetchall()}
    if columns and "cow_id" not in columns:
        conn.execute(
            "ALTER TABLE measurements "
            "ADD COLUMN cow_id INTEGER REFERENCES cow_session(cow_id)"
        )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_meas_cow_ts "
        "ON measurements(cow_id, ts_utc_ms)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_cow_session_open "
        "ON cow_session(stop_time)"
    )


def verify_password(password, encoded_hash):
    try:
        algorithm, iterations, salt_hex, expected_hex = encoded_hash.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            bytes.fromhex(salt_hex),
            int(iterations),
        ).hex()
        return hmac.compare_digest(actual, expected_hex)
    except Exception:
        return False


def measurement_columns(conn):
    return {row["name"] for row in conn.execute("PRAGMA table_info(measurements)").fetchall()}


def weight_select_expr(conn):
    columns = measurement_columns(conn)
    if "weight_lbs" in columns:
        return "weight_lbs"
    if "grams" in columns:
        return f"(grams / {GRAMS_PER_LB}) AS weight_lbs"
    raise sqlite3.Error("measurements table needs weight_lbs or grams column")


def weight_insert_target(conn):
    columns = measurement_columns(conn)
    if "weight_lbs" in columns:
        return "weight_lbs", 1.0
    if "grams" in columns:
        return "grams", GRAMS_PER_LB
    raise sqlite3.Error("measurements table needs weight_lbs or grams column")


def raw_weight_select_expr(conn):
    # The transcriber tares before storage, so weight_lbs is already the true weight - the
    # untared reading (needed to establish a new tare baseline) lives in raw_weight_lbs
    # instead. Older rows predating that column (or the whole raw/offset migration) fall
    # back to weight_lbs, since true historical raw is unrecoverable for them.
    columns = measurement_columns(conn)
    if "raw_weight_lbs" in columns:
        return "COALESCE(raw_weight_lbs, weight_lbs) AS weight_lbs"
    return weight_select_expr(conn)


def send_json(handler, payload, status=200):
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def send_file(handler, path, filename):
    data = Path(path).read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "application/vnd.sqlite3")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


def bad_request(handler, message, status=400):
    send_json(handler, {"error": message}, status)


def read_json(handler):
    length = int(handler.headers.get("Content-Length", "0"))
    if length <= 0:
        raise ValueError("Missing JSON body")
    body = handler.rfile.read(length)
    return json.loads(body.decode("utf-8"))


def cookie_value(handler, name):
    header = handler.headers.get("Cookie", "")
    for part in header.split(";"):
        if "=" not in part:
            continue
        key, value = part.strip().split("=", 1)
        if key == name:
            return value
    return ""


def is_admin(handler):
    # Auth disabled for now - small research team, dev environment only.
    # Re-enable by restoring: return cookie_value(handler, "ls_admin") in ADMIN_SESSIONS
    return True


def require_admin(handler):
    if not is_admin(handler):
        send_json(handler, {"error": "Admin login required"}, 401)
        return False
    return True


def send_login(handler):
    payload = read_json(handler)
    username = str(payload.get("username") or "")
    password = str(payload.get("password") or "")
    if not (secrets.compare_digest(username, ADMIN_USER) and verify_password(password, ADMIN_PASSWORD_HASH)):
        send_json(handler, {"ok": False, "error": "Invalid username or password"}, 401)
        return
    token = secrets.token_urlsafe(32)
    ADMIN_SESSIONS.add(token)
    body = json.dumps({"ok": True, "admin": True}, separators=(",", ":")).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Set-Cookie", f"ls_admin={token}; Path=/; HttpOnly; SameSite=Lax")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def send_logout(handler):
    token = cookie_value(handler, "ls_admin")
    if token:
        ADMIN_SESSIONS.discard(token)
    body = json.dumps({"ok": True}, separators=(",", ":")).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Set-Cookie", "ls_admin=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def cow_label(index):
    return f"Cow-{index + 1}"


def get_cows():
    with connect() as conn:
        ensure_app_tables(conn)
        rows = conn.execute(
            """
            SELECT set_id, COUNT(*) AS sample_count, MIN(ts_utc_ms) AS first_ts,
                   MAX(ts_utc_ms) AS last_ts, MAX(id) AS last_id
            FROM measurements
            GROUP BY set_id
            ORDER BY first_ts DESC
            """
        ).fetchall()
    cows = []
    for index, row in enumerate(rows):
        session = get_session_start_for_cow(conn, row["set_id"], row["first_ts"])
        duration = max(0, (row["last_ts"] - session) / 1000)
        cows.append(
            {
                "id": row["set_id"],
                "label": cow_label(index),
                "rfid": row["set_id"],
                "sampleCount": row["sample_count"],
                "firstTs": row["first_ts"],
                "lastTs": row["last_ts"],
                "lastId": row["last_id"],
                "sessionStartTs": session,
                "durationSec": duration,
            }
        )
    return cows


def get_active_cow_session():
    with connect() as conn:
        ensure_app_tables(conn)
        row = conn.execute(
            """
            SELECT cow_id, start_time, stop_time
            FROM cow_session
            WHERE stop_time IS NULL
            ORDER BY cow_id DESC
            LIMIT 1
            """
        ).fetchone()
    return dict(row) if row else None


def get_detected_sessions(limit=100):
    limit = min(max(int(limit), 1), 1000)
    with connect() as conn:
        ensure_app_tables(conn)
        rows = conn.execute(
            """
            SELECT s.cow_id, s.start_time, s.stop_time,
                   COUNT(m.id) AS measurement_count
            FROM cow_session AS s
            LEFT JOIN measurements AS m ON m.cow_id = s.cow_id
            GROUP BY s.cow_id, s.start_time, s.stop_time
            ORDER BY s.cow_id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def get_devices():
    statuses = read_device_status()
    plate_ids = {status["device_id"] for status in statuses if status.get("device_id")}

    latest_by_plate = {}
    if plate_ids and DB_PATH.exists():
        with connect() as conn:
            weight_expr = weight_select_expr(conn)
            placeholders = ",".join("?" for _ in plate_ids)
            rows = conn.execute(
                """
                WITH latest AS (
                  SELECT plate, MAX(ts_utc_ms) AS max_ts
                  FROM measurements
                  WHERE plate IN ({placeholders})
                  GROUP BY plate
                )
                SELECT m.plate, m.ts_utc_ms, {weight_expr}
                FROM measurements m
                JOIN latest l ON l.plate = m.plate AND l.max_ts = m.ts_utc_ms
                """.format(placeholders=placeholders, weight_expr=weight_expr),
                tuple(plate_ids),
            ).fetchall()
        for row in rows:
            latest_by_plate[row["plate"]] = {
                "weightLbs": float(row["weight_lbs"]),
                "lastDataTs": row["ts_utc_ms"],
            }

    now_ms = int(time.time() * 1000)
    conflict_plates = {
        entry["device_id"]
        for entry in read_recent_rejects(200)
        if entry.get("reason", "").startswith("duplicate")
        and now_ms - entry.get("ts_utc_ms", 0) <= DEVICE_CONFLICT_WINDOW_MS
    }

    devices = []
    for status in statuses:
        device_id = status.get("device_id")
        data_info = latest_by_plate.get(device_id, {})
        devices.append(
            {
                "port": status["port"],
                "state": status.get("state", "disconnected"),
                "plate": device_id,
                "weightLbs": data_info.get("weightLbs"),
                "lastDataTs": data_info.get("lastDataTs"),
                "connectedSince": status.get("opened_at_ms"),
                "disconnectedAt": status.get("disconnected_at_ms"),
                "conflict": bool(device_id) and device_id in conflict_plates,
            }
        )
    return devices


def plate_to_leg(plate):
    parts = plate.split("_")
    if not parts:
        return None
    code = parts[-1][:2]
    return LEG_MAP.get(code, (None, None))[0]


def normalize_plate(set_id, plate):
    plate = str(plate).strip().lower()
    if plate in PLATE_SUFFIXES:
        return f"{set_id}_{plate}"
    return plate


def ingest_measurements(payload):
    set_id = str(payload.get("set_id") or payload.get("cow") or payload.get("rfid") or "").strip()
    if not set_id:
        raise ValueError("Missing set_id/cow/rfid")

    ts_ms = payload.get("ts_utc_ms") or payload.get("timestamp_ms") or int(time.time() * 1000)
    ts_ms = int(ts_ms)
    device_id = str(payload.get("device_id") or "esp32")
    rows = []

    unit = str(payload.get("unit") or payload.get("units") or "lb").lower()
    multiplier_to_lbs = 1 / GRAMS_PER_LB if unit in ("g", "gram", "grams") else 1.0

    if isinstance(payload.get("weights"), dict):
        for plate, weight in payload["weights"].items():
            rows.append((set_id, normalize_plate(set_id, plate), device_id, ts_ms, float(weight) * multiplier_to_lbs))

    if isinstance(payload.get("plates"), list):
        for item in payload["plates"]:
            if not isinstance(item, dict):
                continue
            plate = item.get("plate") or item.get("id") or item.get("name")
            weight = item.get("weight_lbs") if "weight_lbs" in item else item.get("weight")
            row_ts = int(item.get("ts_utc_ms") or ts_ms)
            row_device = str(item.get("device_id") or device_id)
            if plate is not None and weight is not None:
                row_unit = str(item.get("unit") or item.get("units") or unit).lower()
                row_multiplier = 1 / GRAMS_PER_LB if row_unit in ("g", "gram", "grams") else 1.0
                rows.append((set_id, normalize_plate(set_id, plate), row_device, row_ts, float(weight) * row_multiplier))

    if payload.get("plate") is not None and (payload.get("weight_lbs") is not None or payload.get("grams") is not None):
        if payload.get("weight_lbs") is not None:
            weight_lbs = float(payload["weight_lbs"])
        else:
            weight_lbs = float(payload["grams"]) / GRAMS_PER_LB
        rows.append(
            (
                set_id,
                normalize_plate(set_id, payload["plate"]),
                device_id,
                ts_ms,
                weight_lbs,
            )
        )

    if not rows:
        raise ValueError("No plate weights found. Send weights, plates, or plate + weight_lbs")

    with connect() as conn:
        weight_column, insert_multiplier = weight_insert_target(conn)
        stored_rows = [
            (set_id, plate, row_device, row_ts, weight_lbs * insert_multiplier)
            for set_id, plate, row_device, row_ts, weight_lbs in rows
        ]
        conn.executemany(
            f"""
            INSERT INTO measurements (set_id, plate, device_id, ts_utc_ms, {weight_column})
            VALUES (?, ?, ?, ?, ?)
            """,
            stored_rows,
        )
        conn.commit()
        first_id = conn.execute("SELECT last_insert_rowid() - ? + 1", (len(rows),)).fetchone()[0]
        max_id = conn.execute("SELECT MAX(id) FROM measurements WHERE set_id = ?", (set_id,)).fetchone()[0]

    return {"ok": True, "cow": set_id, "inserted": len(rows), "firstId": first_id, "maxId": max_id}


def get_session_start_for_cow(conn, set_id, fallback=None):
    ensure_app_tables(conn)
    row = conn.execute(
        "SELECT session_start_ms FROM cow_sessions WHERE set_id = ?",
        (set_id,),
    ).fetchone()
    if row:
        return int(row["session_start_ms"])
    if fallback is not None:
        return int(fallback)
    first = conn.execute(
        "SELECT MIN(ts_utc_ms) AS first_ts FROM measurements WHERE set_id = ?",
        (set_id,),
    ).fetchone()
    if first and first["first_ts"] is not None:
        return int(first["first_ts"])
    return int(time.time() * 1000)


def set_session_start(conn, set_id, start_ms):
    ensure_app_tables(conn)
    now_ms = int(time.time() * 1000)
    conn.execute(
        """
        INSERT INTO cow_sessions (set_id, session_start_ms, updated_ms)
        VALUES (?, ?, ?)
        ON CONFLICT(set_id) DO UPDATE SET
          session_start_ms = excluded.session_start_ms,
          updated_ms = excluded.updated_ms
        """,
        (set_id, int(start_ms), now_ms),
    )


def group_rows(rows, seed=None):
    # Plates on independent serial streams (separate ports/devices) almost never share the
    # exact same ts_utc_ms, so bucketing by exact timestamp alone would make every other
    # plate read as 0 in a bucket it didn't happen to write to. Carry each plate's last known
    # weight forward into new buckets so a point reflects the latest known state of every
    # plate, not just the one that happened to write at that exact millisecond.
    #
    # `seed` carries that state in from a previous call - without it, an incremental fetch
    # (only the rows newer than some id) would reset every other plate to 0 for however many
    # points it takes for that plate to report a new row of its own, which is exactly the
    # peak-then-drop-to-0-then-peak-again flicker seen when polling for live updates.
    #
    # weight_lbs is already tared (the transcriber computes raw - offset before it's ever
    # stored), so this just reads it straight - no offset lookup needed here at all.
    grouped = {}
    first_ts = min((row["ts_utc_ms"] for row in rows), default=None)
    max_id = max((row["id"] for row in rows), default=0)
    last_known = dict(seed) if seed else {}
    for row in rows:
        ts = row["ts_utc_ms"]
        if ts not in grouped:
            grouped[ts] = {
                "id": row["id"],
                "ts": ts,
                "t": 0 if first_ts is None else (ts - first_ts) / 1000,
                "plates": dict(last_known),
            }
        bucket = grouped[ts]
        bucket["id"] = max(bucket["id"], row["id"])
        weight = max(0, float(row["weight_lbs"]))
        bucket["plates"][row["plate"]] = weight
        last_known[row["plate"]] = weight

    points = []
    for item in sorted(grouped.values(), key=lambda point: point["ts"]):
        legs = {"frontLeft": 0, "frontRight": 0, "backLeft": 0, "backRight": 0}
        for plate, weight in item["plates"].items():
            leg = plate_to_leg(plate)
            if leg:
                legs[leg] += weight
        item["legs"] = legs
        item["left"] = legs["frontLeft"] + legs["backLeft"]
        item["right"] = legs["frontRight"] + legs["backRight"]
        item["front"] = legs["frontLeft"] + legs["frontRight"]
        item["back"] = legs["backLeft"] + legs["backRight"]
        item["total"] = item["left"] + item["right"]
        points.append(item)
    return points, max_id


def seed_last_known(conn, set_id, before_id, session_start):
    weight_expr = weight_select_expr(conn)
    rows = conn.execute(
        """
        WITH latest AS (
          SELECT plate, MAX(id) AS max_id
          FROM measurements
          WHERE set_id = ? AND id <= ? AND ts_utc_ms >= ?
          GROUP BY plate
        )
        SELECT m.plate, {weight_expr}
        FROM measurements m
        JOIN latest l ON l.plate = m.plate AND l.max_id = m.id
        """.format(weight_expr=weight_expr),
        (set_id, before_id, session_start),
    ).fetchall()
    return {row["plate"]: max(0, float(row["weight_lbs"])) for row in rows}


def active_session_start(conn, set_id):
    session_start = get_session_start_for_cow(conn, set_id)
    row = conn.execute(
        "SELECT MAX(ts_utc_ms) AS last_ts FROM measurements WHERE set_id = ?",
        (set_id,),
    ).fetchone()
    if not row or row["last_ts"] is None:
        return session_start
    rolling_start = max(0, int(row["last_ts"]) - SESSION_WINDOW_MS)
    return max(session_start, rolling_start)


def get_series(set_id, after_id=0, limit=6000):
    with connect() as conn:
        ensure_app_tables(conn)
        weight_expr = weight_select_expr(conn)
        session_start = active_session_start(conn, set_id)
        if after_id > 0:
            first_ts_row = conn.execute(
                "SELECT MIN(ts_utc_ms) AS first_ts FROM measurements WHERE set_id = ? AND ts_utc_ms >= ?",
                (set_id, session_start),
            ).fetchone()
            base_ts = get_session_start_for_cow(conn, set_id, first_ts_row["first_ts"] if first_ts_row else None)
            rows = conn.execute(
                """
                SELECT id, set_id, plate, device_id, ts_utc_ms, {weight_expr}
                FROM measurements
                WHERE set_id = ? AND id > ? AND ts_utc_ms >= ?
                ORDER BY ts_utc_ms, id
                LIMIT ?
                """.format(weight_expr=weight_expr),
                (set_id, after_id, session_start, limit),
            ).fetchall()
            seed = seed_last_known(conn, set_id, after_id, session_start)
            points, max_id = group_rows(rows, seed=seed)
            for point in points:
                point["t"] = (point["ts"] - base_ts) / 1000 if base_ts else 0
            return points, max_id

        rows = conn.execute(
            """
            SELECT id, set_id, plate, device_id, ts_utc_ms, {weight_expr}
            FROM measurements
            WHERE set_id = ? AND ts_utc_ms >= ?
            ORDER BY ts_utc_ms, id
            LIMIT ?
            """.format(weight_expr=weight_expr),
            (set_id, session_start, limit),
        ).fetchall()
        points, max_id = group_rows(rows)
        base_ts = get_session_start_for_cow(conn, set_id, rows[0]["ts_utc_ms"] if rows else None)
        for point in points:
            point["t"] = (point["ts"] - base_ts) / 1000 if base_ts else 0
        return points, max_id


def reset_cow(set_id):
    # Resetting only starts a new session view (session_start_ms). Tare is a property of the
    # physical plate's zero-point, not of which cow is currently being viewed, so it's
    # intentionally left untouched here - only an explicit tare (manual or auto-on-connect)
    # should change it.
    if not set_id:
        raise ValueError("Missing cow")
    now_ms = int(time.time() * 1000)
    with connect() as conn:
        ensure_app_tables(conn)
        set_session_start(conn, set_id, now_ms)
        conn.commit()
    return {"ok": True, "cow": set_id, "sessionStartTs": now_ms}


def latest_raw_plate_weights(conn, set_id):
    raw_expr = raw_weight_select_expr(conn)
    session_start = active_session_start(conn, set_id)
    rows = conn.execute(
        """
        WITH latest AS (
          SELECT plate, MAX(ts_utc_ms) AS max_ts
          FROM measurements
          WHERE set_id = ? AND ts_utc_ms >= ?
          GROUP BY plate
        )
        SELECT m.plate, m.ts_utc_ms, {raw_expr}
        FROM measurements m
        JOIN latest l ON l.plate = m.plate AND l.max_ts = m.ts_utc_ms
        WHERE m.set_id = ?
        """.format(raw_expr=raw_expr),
        (set_id, session_start, set_id),
    ).fetchall()
    latest = {}
    for row in rows:
        latest[row["plate"]] = max(latest.get(row["plate"], 0), float(row["weight_lbs"]))
    return latest


def tare_cow(set_id):
    if not set_id:
        raise ValueError("Missing cow")
    now_ms = int(time.time() * 1000)
    with connect() as conn:
        ensure_app_tables(conn)
        latest = latest_raw_plate_weights(conn, set_id)
        if not latest:
            raise ValueError("No current readings for cow")
        conn.executemany(
            """
            INSERT INTO tare_offsets (set_id, plate, offset_lbs, created_ms)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(set_id, plate) DO UPDATE SET
              offset_lbs = excluded.offset_lbs,
              created_ms = excluded.created_ms
            """,
            [(set_id, plate, value, now_ms) for plate, value in latest.items()],
        )
        conn.commit()
    return {"ok": True, "cow": set_id, "plates": len(latest)}


def derive_set_id(plate):
    # Expect formats like "plate_01_flo" -> set="plate_01" (matches the same convention used
    # in forceplate_writer.py/forceplate_transcriber.py; kept local since these modules don't
    # share imports beyond the small dedicated helper files).
    parts = plate.split("_")
    if len(parts) >= 3:
        return "_".join(parts[:2])
    return plate


def tare_plate(plate):
    if not plate:
        raise ValueError("Missing plate")
    set_id = derive_set_id(plate)
    now_ms = int(time.time() * 1000)
    with connect() as conn:
        ensure_app_tables(conn)
        latest = latest_raw_plate_weights(conn, set_id)
        if plate not in latest:
            raise ValueError(f"No current readings for plate {plate}")
        conn.execute(
            """
            INSERT INTO tare_offsets (set_id, plate, offset_lbs, created_ms)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(set_id, plate) DO UPDATE SET
              offset_lbs = excluded.offset_lbs,
              created_ms = excluded.created_ms
            """,
            (set_id, plate, latest[plate], now_ms),
        )
        conn.commit()
    return {"ok": True, "plate": plate, "offsetLbs": latest[plate]}


def backup_database():
    fd, tmp_path = tempfile.mkstemp(prefix="lamescore-", suffix=".db")
    os.close(fd)
    source = sqlite3.connect(DB_PATH, timeout=2.0)
    target = sqlite3.connect(tmp_path)
    try:
        source.backup(target)
    finally:
        target.close()
        source.close()
    return tmp_path


def avg(values):
    return statistics.fmean(values) if values else 0


def pct_delta(a, b):
    denom = max((a + b) / 2, 1)
    return abs(a - b) / denom


def summarize(points):
    if not points:
        return {
            "lameScore": 0,
            "status": "No data",
            "leftAvg": 0,
            "rightAvg": 0,
            "frontAvg": 0,
            "backAvg": 0,
            "totalAvg": 0,
            "totalCurrent": 0,
            "legAverages": {},
            "durationSec": 0,
        }

    left_avg = avg([p["left"] for p in points])
    right_avg = avg([p["right"] for p in points])
    front_avg = avg([p["front"] for p in points])
    back_avg = avg([p["back"] for p in points])
    leg_avgs = {
        key: avg([p["legs"][key] for p in points])
        for key in ["frontLeft", "frontRight", "backLeft", "backRight"]
    }
    leg_mean = avg(leg_avgs.values())
    max_leg_delta = max((abs(value - leg_mean) / max(leg_mean, 1) for value in leg_avgs.values()), default=0)
    lr_delta = pct_delta(left_avg, right_avg)
    fb_delta = pct_delta(front_avg, back_avg)
    score = round(min(100, (lr_delta * 0.45 + fb_delta * 0.25 + max_leg_delta * 0.30) * 100))

    status = "Normal"
    if score >= 35:
        status = "High watch"
    elif score >= 18:
        status = "Monitor"

    return {
        "lameScore": score,
        "status": status,
        "leftAvg": left_avg,
        "rightAvg": right_avg,
        "frontAvg": front_avg,
        "backAvg": back_avg,
        "totalAvg": avg([p["total"] for p in points]),
        "totalCurrent": points[-1]["total"],
        "legAverages": leg_avgs,
        "lrDeltaPct": lr_delta * 100,
        "fbDeltaPct": fb_delta * 100,
        "durationSec": max(point["t"] for point in points),
    }


def api(handler):
    parsed = urlparse(handler.path)
    params = parse_qs(parsed.query)
    try:
        if not DB_PATH.exists():
            bad_request(handler, f"Database not found at {DB_PATH}", 404)
            return
        if parsed.path == "/api/health":
            send_json(handler, {"ok": True, "db": str(DB_PATH), "time": int(time.time())})
            return
        if parsed.path == "/api/admin/status":
            send_json(handler, {"admin": is_admin(handler), "username": ADMIN_USER if is_admin(handler) else ""})
            return
        if parsed.path == "/api/admin/download":
            if not require_admin(handler):
                return
            backup = backup_database()
            try:
                send_file(handler, backup, f"lamescore-{int(time.time())}.db")
            finally:
                try:
                    os.remove(backup)
                except OSError:
                    pass
            return
        if parsed.path == "/api/rejects":
            limit = int(params.get("limit", ["50"])[0])
            send_json(handler, {"rejects": read_recent_rejects(limit)})
            return
        if parsed.path == "/api/devices":
            send_json(handler, {"devices": get_devices()})
            return
        if parsed.path == "/api/cows":
            send_json(handler, {"cows": get_cows()})
            return
        if parsed.path == "/api/session/active":
            send_json(handler, {"session": get_active_cow_session()})
            return
        if parsed.path == "/api/sessions":
            limit = int(params.get("limit", ["100"])[0])
            send_json(handler, {"sessions": get_detected_sessions(limit)})
            return
        if parsed.path in ("/api/series", "/api/latest", "/api/summary"):
            set_id = params.get("cow", [""])[0]
            if not set_id:
                cows = get_cows()
                set_id = cows[0]["id"] if cows else ""
            if not set_id:
                bad_request(handler, "No cow/session data found", 404)
                return
            after_id = int(params.get("after", ["0"])[0])
            points, max_id = get_series(set_id, after_id=after_id)
            summary_points = points
            if parsed.path == "/api/latest":
                summary_points, summary_max_id = get_series(set_id)
                max_id = max(max_id, summary_max_id)
            if parsed.path == "/api/summary":
                send_json(handler, {"cow": set_id, "summary": summarize(points), "maxId": max_id})
            else:
                send_json(handler, {"cow": set_id, "points": points, "maxId": max_id, "summary": summarize(summary_points)})
            return
        bad_request(handler, "Unknown API route", 404)
    except sqlite3.Error as exc:
        bad_request(handler, f"SQLite error: {exc}", 500)
    except ValueError as exc:
        bad_request(handler, f"Bad parameter: {exc}", 400)


def api_post(handler):
    parsed = urlparse(handler.path)
    try:
        if not DB_PATH.exists():
            bad_request(handler, f"Database not found at {DB_PATH}", 404)
            return
        if parsed.path == "/api/ingest":
            send_json(handler, ingest_measurements(read_json(handler)))
            return
        if parsed.path == "/api/admin/login":
            send_login(handler)
            return
        if parsed.path == "/api/admin/logout":
            send_logout(handler)
            return
        if parsed.path == "/api/admin/reset":
            if not require_admin(handler):
                return
            payload = read_json(handler)
            send_json(handler, reset_cow(str(payload.get("cow") or payload.get("set_id") or "").strip()))
            return
        if parsed.path == "/api/admin/tare":
            if not require_admin(handler):
                return
            payload = read_json(handler)
            send_json(handler, tare_cow(str(payload.get("cow") or payload.get("set_id") or "").strip()))
            return
        if parsed.path == "/api/admin/tare-plate":
            if not require_admin(handler):
                return
            payload = read_json(handler)
            send_json(handler, tare_plate(str(payload.get("plate") or "").strip()))
            return
        bad_request(handler, "Unknown API route", 404)
    except json.JSONDecodeError as exc:
        bad_request(handler, f"Invalid JSON: {exc}", 400)
    except sqlite3.Error as exc:
        bad_request(handler, f"SQLite error: {exc}", 500)
    except ValueError as exc:
        bad_request(handler, f"Bad parameter: {exc}", 400)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def end_headers(self):
        # Always disable caching (dev tool, small payloads) so edits to static
        # files show up on refresh instead of being served from browser cache.
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_GET(self):
        if self.path.startswith("/api/"):
            api(self)
            return
        if self.path == "/":
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self):
        if self.path.startswith("/api/"):
            api_post(self)
            return
        bad_request(self, "POST is only supported for API routes", 404)

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))


def main():
    port = int(os.environ.get("PORT", "8080"))
    host = os.environ.get("HOST", "127.0.0.1")
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"LameScore running at http://{host}:{port}")
    print(f"Reading SQLite database: {DB_PATH}")
    print("NOTE: admin auth is disabled (dev mode) - all admin actions are open.")
    server.serve_forever()


if __name__ == "__main__":
    main()
