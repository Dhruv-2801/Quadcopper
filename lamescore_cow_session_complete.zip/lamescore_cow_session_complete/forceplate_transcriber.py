#!/usr/bin/env python3
"""
Transcriber discovers ESP32 serial ports, reads newline-delimited JSON from each,
normalizes fields, and emits the records.
"""
import sys, os, time, json, sqlite3, threading, glob
from pathlib import Path
import serial, serial.tools.list_ports as lp

from plate_naming import is_valid_device_id, log_rejected_plate
from device_status import mark_connected, mark_device_id, mark_disconnected

APP_DIR = Path(__file__).resolve().parent
DEFAULT_DB = APP_DIR / "data" / "forceplate.db"
FORCEPLATE_DB = os.environ.get("FORCEPLATE_DB", str(DEFAULT_DB))

stdout_lock = threading.Lock()
ESP_VID = 0x303A         # Espressif VID
BAUD    = 115200
RESCAN_S = 5             # rescan for new ports every N seconds
STALE_OWNER_S = 5        # if the owning port hasn't sent this id in this long, let another port claim it
DUPLICATE_WARN_COOLDOWN_S = 30  # don't re-log the same duplicate collision more than this often
OFFSET_REFRESH_S = 5     # how often to reload tare offsets from the DB
AUTO_TARE_SETTLE_S = 5   # wait this long after a plate's id resolves before auto-taring it

active_plates = {}       # device_id -> {"port": port, "last_seen": epoch_seconds}
last_duplicate_warning = {}  # device_id -> epoch_seconds of last logged collision
port_last_device = {}    # port -> last device_id reported, so we only touch disk on change
offset_cache = {}        # plate (device_id) -> current tare offset, refreshed periodically
device_first_seen = {}   # port -> epoch_seconds when its device_id first resolved
auto_tared_ports = set()  # ports that already got their settle-period auto-tare this connection


TARE_OFFSETS_SCHEMA = """
CREATE TABLE IF NOT EXISTS tare_offsets (
  set_id        TEXT NOT NULL,
  plate         TEXT NOT NULL,
  offset_lbs    REAL NOT NULL,
  created_ms    INTEGER NOT NULL,
  PRIMARY KEY (set_id, plate)
)
"""


def derive_set_id(device_id):
    # Expect formats like "plate_01_flo" -> set="plate_01" (matches forceplate_writer.py's
    # split_set_and_plate, kept as a separate small helper since the transcriber and writer
    # only talk to each other over the stdout/stdin pipe, not via shared imports).
    parts = device_id.split("_")
    if len(parts) >= 3:
        return "_".join(parts[:2])
    return device_id


def refresh_offset_cache():
    global offset_cache
    try:
        conn = sqlite3.connect(FORCEPLATE_DB, timeout=2.0)
        conn.execute(TARE_OFFSETS_SCHEMA)
        rows = conn.execute("SELECT plate, offset_lbs FROM tare_offsets").fetchall()
        conn.close()
        offset_cache = {plate: float(offset) for plate, offset in rows}
    except Exception as e:
        print(f"[tare] WARN: failed to refresh offset cache: {e}", file=sys.stderr)


def write_tare_offset(device_id, offset):
    set_id = derive_set_id(device_id)
    try:
        conn = sqlite3.connect(FORCEPLATE_DB, timeout=2.0)
        conn.execute(TARE_OFFSETS_SCHEMA)
        conn.execute(
            """
            INSERT INTO tare_offsets (set_id, plate, offset_lbs, created_ms)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(set_id, plate) DO UPDATE SET
              offset_lbs = excluded.offset_lbs,
              created_ms = excluded.created_ms
            """,
            (set_id, device_id, offset, int(time.time() * 1000)),
        )
        conn.commit()
        conn.close()
        offset_cache[device_id] = offset
    except Exception as e:
        print(f"[tare] ERROR writing offset for {device_id}: {e}", file=sys.stderr)

def list_esp_ports():
    # Prefer VID filter; fall back to ttyACM* if VID missing
    ports = [p.device for p in lp.comports() if p.vid == ESP_VID]
    if not ports:
        ports = sorted(glob.glob("/dev/ttyACM*"))
    return sorted(set(ports))

def reader(port):
    mark_connected(port)
    try:
        with serial.Serial(port, BAUD, timeout=1) as ser:
            time.sleep(0.3)
            print(f"[{port}] OPEN", file=sys.stderr)
            while True:
                line = ser.readline()
                if not line:
                    continue
                s = line.decode("utf-8", errors="ignore").strip()
                if not s:
                    continue

                try:
                    obj = json.loads(s)
                except json.JSONDecodeError:
                    start, end = s.find('{'), s.rfind('}')
                    if start != -1 and end != -1 and end > start:
                        try:
                            obj = json.loads(s[start:end+1])
                        except Exception:
                            print(f"[{port}] SKIP non-JSON: {s}", file=sys.stderr)
                            continue
                    else:
                        print(f"[{port}] SKIP non-JSON: {s}", file=sys.stderr)
                        continue

                if "device_id" not in obj or "weight" not in obj:
                    print(f"[{port}] SKIP missing fields: {s}", file=sys.stderr)
                    continue

                device_id = str(obj["device_id"]).strip()
                if not is_valid_device_id(device_id):
                    log_rejected_plate(device_id, source=port)
                    print(f"[{port}] REJECTED plate detected but id not recognized: {device_id}", file=sys.stderr)
                    continue

                now = time.time()
                owner = active_plates.get(device_id)
                if owner and owner["port"] != port and (now - owner["last_seen"]) < STALE_OWNER_S:
                    last_warned = last_duplicate_warning.get(device_id, 0)
                    if now - last_warned >= DUPLICATE_WARN_COOLDOWN_S:
                        log_rejected_plate(
                            device_id,
                            source=port,
                            reason=f"duplicate plate id (also reporting from {owner['port']})",
                        )
                        last_duplicate_warning[device_id] = now
                    print(f"[{port}] REJECTED duplicate plate id (also on {owner['port']}): {device_id}", file=sys.stderr)
                    continue
                active_plates[device_id] = {"port": port, "last_seen": now}
                if port_last_device.get(port) != device_id:
                    mark_device_id(port, device_id)
                    port_last_device[port] = device_id
                    device_first_seen.setdefault(port, now)

                try:
                    raw_w = float(obj["weight"])
                except Exception:
                    raw_w = None

                if raw_w is not None:
                    if port not in auto_tared_ports and now - device_first_seen.get(port, now) >= AUTO_TARE_SETTLE_S:
                        write_tare_offset(device_id, raw_w)
                        auto_tared_ports.add(port)
                        print(f"[{port}] AUTO-TARE {device_id} -> offset={raw_w}", file=sys.stderr)

                    offset = offset_cache.get(device_id, 0.0)
                    obj["weight"] = max(0.0, raw_w - offset)
                    obj["raw_weight"] = raw_w
                    obj["tare_offset"] = offset

                with stdout_lock:
                    print(json.dumps(obj, separators=(",", ":")), flush=True)

    except Exception as e:
        mark_disconnected(port, error=e)
        print(f"[{port}] ERROR: {e}", file=sys.stderr)
    finally:
        print(f"[{port}] CLOSED", file=sys.stderr)
        port_last_device.pop(port, None)
        device_first_seen.pop(port, None)
        auto_tared_ports.discard(port)


def main():
    threads = {}
    last_scan = 0
    last_offset_refresh = 0
    refresh_offset_cache()

    while True:
        now = time.time()

        for p in list(threads.keys()):
            if not threads[p].is_alive():
                del threads[p]

        if now - last_scan >= RESCAN_S:
            last_scan = now
            for p in list_esp_ports():
                if p not in threads:
                    t = threading.Thread(target=reader, args=(p,), daemon=True)
                    t.start()
                    threads[p] = t

        if now - last_offset_refresh >= OFFSET_REFRESH_S:
            last_offset_refresh = now
            refresh_offset_cache()

        time.sleep(0.5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass