-- DE2_115_wrapper.vhd — JTAG-UART program loading version (v2)
--
-- Architecture:
--   * JTAG UART IP + byte-read FSM + uart_loader all run on ONE constant
--     clock, s_clk_load = 12.5 MHz. The CPU is forced onto this same clock
--     while loading (load_done='0'), so IMem writes are never dropped.
--     (Previous version clocked the loader at CLOCK_50 and the CPU at
--     12.5 MHz — 3 of every 4 instruction words were silently lost.)
--   * The read FSM HOLDS av_read_n low until waitrequest deasserts
--     (Avalon-MM rule) and validates bytes with RVALID = readdata(15),
--     so no optional dataavailable/readyfordata exports are needed.
--   * CPU reset = POR  OR  program-not-loaded  OR  SW0  OR  a 64-cycle
--     stretch after load_done rises (absorbs the fast->slow clock mux).
--   * SWITCH-CONTROLLED (pushbuttons on this board are unreliable):
--       SW0 up   = hold CPU in reset. Toggle up then down = re-run program.
--       SW1 up   = wipe the loader (and diag flags). Toggle up then down,
--                  then send a NEW program - no FPGA reprogramming needed.
--
-- Debug LEDs:
--   LEDG0 = CPU reset          LEDG1 = POR done
--   LEDG2 = CPU clock          LEDG3 = load_done (program in IMem)
--   LEDG8 = live ALU activity
--   LEDR  = while loading: number of words received (watch it count up!)
--           after loading:  live ALUOut(17:0)
--
-- Switches:
--   SW0  = up: CPU held in reset (toggle up->down to re-run)
--   SW1  = up: loader + diagnostics wiped (toggle up->down before re-send)
--   SW16 = 0: HEX shows live ALUOut   1: HEX shows held last non-zero value
--   SW17 = 0: CPU at 12.5 MHz   1: CPU at ~1.5 Hz (only after loading)

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;
library work;
use work.RISCV_types.all;

entity DE2_115_wrapper is
    port (
        CLOCK_50 : in  std_logic;
        KEY      : in  std_logic_vector(3 downto 0);
        SW       : in  std_logic_vector(17 downto 0);
        LEDR     : out std_logic_vector(17 downto 0);
        LEDG     : out std_logic_vector(8  downto 0);
        HEX0     : out std_logic_vector(6  downto 0);
        HEX1     : out std_logic_vector(6  downto 0);
        HEX2     : out std_logic_vector(6  downto 0);
        HEX3     : out std_logic_vector(6  downto 0);
        HEX4     : out std_logic_vector(6  downto 0);
        HEX5     : out std_logic_vector(6  downto 0);
        HEX6     : out std_logic_vector(6  downto 0);
        HEX7     : out std_logic_vector(6  downto 0)
    );
end entity DE2_115_wrapper;

architecture structural of DE2_115_wrapper is

    component RISCV_Processor is
        generic (N : integer := DATA_WIDTH);
        port (
            iCLK      : in  std_logic;
            iRST      : in  std_logic;
            iInstLd   : in  std_logic;
            iInstAddr : in  std_logic_vector(N-1 downto 0);
            iInstExt  : in  std_logic_vector(N-1 downto 0);
            oALUOut   : out std_logic_vector(N-1 downto 0)
        );
    end component;

    -- Qsys system "wrapper" (Platform Designer) containing the JTAG UART IP.
    -- Port names copied VERBATIM from the generated wrapper/synthesis/wrapper.v
    component wrapper is
        port (
            clk_clk                                   : in  std_logic;
            jtag_uart_0_avalon_jtag_slave_chipselect  : in  std_logic;
            jtag_uart_0_avalon_jtag_slave_address     : in  std_logic;
            jtag_uart_0_avalon_jtag_slave_read_n      : in  std_logic;
            jtag_uart_0_avalon_jtag_slave_readdata    : out std_logic_vector(31 downto 0);
            jtag_uart_0_avalon_jtag_slave_write_n     : in  std_logic;
            jtag_uart_0_avalon_jtag_slave_writedata   : in  std_logic_vector(31 downto 0);
            jtag_uart_0_avalon_jtag_slave_waitrequest : out std_logic;
            jtag_uart_0_clk_clk                       : in  std_logic;
            jtag_uart_0_irq_irq                       : out std_logic;
            jtag_uart_0_reset_reset_n                 : in  std_logic;
            reset_reset_n                             : in  std_logic
        );
    end component;

    component uart_loader is
        port (
            clk        : in  std_logic;
            rst        : in  std_logic;
            uart_byte  : in  std_logic_vector(7 downto 0);
            uart_valid : in  std_logic;
            mem_we     : out std_logic;
            mem_addr   : out std_logic_vector(31 downto 0);
            mem_data   : out std_logic_vector(31 downto 0);
            word_count : out std_logic_vector(9 downto 0);
            load_done  : out std_logic
        );
    end component;

    constant N : integer := DATA_WIDTH;

    -- ── Clocks ─────────────────────────────────────────────────────────
    signal r_div      : unsigned(24 downto 0) := (others => '0');
    signal s_clk_load : std_logic;   -- constant 12.5 MHz: UART + loader
    signal s_clk_cpu  : std_logic;   -- 12.5 MHz while loading; then SW17 picks

    -- ── Reset ──────────────────────────────────────────────────────────
    -- Switch synchronizers (SW0 = CPU reset, SW1 = loader wipe).
    -- Init '0' = inactive, matching switches in the DOWN position.
    signal r_sw0_meta, r_sw0_sync : std_logic := '0';
    signal r_sw1_meta, r_sw1_sync : std_logic := '0';
    signal r_por_count : unsigned(3 downto 0) := (others => '0');
    signal s_por_done  : std_logic := '0';
    signal r_run_count : unsigned(5 downto 0) := (others => '0');
    signal s_run_rdy   : std_logic := '0';   -- 64 cycles after load_done
    signal s_rst       : std_logic;
    signal s_loader_rst: std_logic;

    -- ── UART byte stream ───────────────────────────────────────────────
    signal uart_readdata    : std_logic_vector(31 downto 0);
    signal uart_waitrequest : std_logic;
    signal uart_read_n      : std_logic := '1';
    signal uart_byte        : std_logic_vector(7 downto 0) := (others => '0');
    signal uart_valid       : std_logic := '0';
    type uart_state_t is (IDLE, RD);
    signal uart_state : uart_state_t := IDLE;

    -- ── Loader ─────────────────────────────────────────────────────────
    signal load_done   : std_logic;
    signal loader_we   : std_logic;
    signal loader_addr : std_logic_vector(31 downto 0);
    signal loader_data : std_logic_vector(31 downto 0);
    signal word_count  : std_logic_vector(9 downto 0);

    -- ── Diagnostics (latched event flags, cleared by KEY3) ─────────────
    signal r_byte_cnt   : unsigned(7 downto 0) := (others => '0');
    signal r_saw_rdack  : std_logic := '0';  -- an Avalon read completed
    signal r_saw_rvalid : std_logic := '0';  -- a completed read carried a byte
    signal r_saw_we     : std_logic := '0';  -- loader wrote a word to IMem

    -- ── Display ────────────────────────────────────────────────────────
    signal s_alu_out  : std_logic_vector(N-1 downto 0);
    signal s_disp_reg : std_logic_vector(N-1 downto 0) := (others => '0');
    signal s_disp_mux : std_logic_vector(N-1 downto 0);

    type seg7_lut_t is array(0 to 15) of std_logic_vector(6 downto 0);
    constant SEG7_LUT : seg7_lut_t := (
        "1000000","1111001","0100100","0110000",
        "0011001","0010010","0000010","1111000",
        "0000000","0010000","0001000","0000011",
        "1000110","0100001","0000110","0001110"
    );
    function to_seg7(n : std_logic_vector(3 downto 0))
        return std_logic_vector is
    begin
        return SEG7_LUT(to_integer(unsigned(n)));
    end function;

begin

    -- ── Clock generation ───────────────────────────────────────────────
    process(CLOCK_50)
    begin
        if rising_edge(CLOCK_50) then
            r_div <= r_div + 1;
        end if;
    end process;

    s_clk_load <= r_div(1);  -- constant 12.5 MHz

    -- CPU is FORCED onto the load clock until the program is in.
    s_clk_cpu <= r_div(1) when (load_done = '0' or SW(17) = '0')
                 else r_div(24);

    -- ── Switch synchronizers (into the load-clock domain) ──────────────
    process(s_clk_load)
    begin
        if rising_edge(s_clk_load) then
            r_sw0_meta <= SW(0);  r_sw0_sync <= r_sw0_meta;
            r_sw1_meta <= SW(1);  r_sw1_sync <= r_sw1_meta;
        end if;
    end process;

    -- ── Power-on reset (16 load-clock cycles) ──────────────────────────
    process(s_clk_load)
    begin
        if rising_edge(s_clk_load) then
            if s_por_done = '0' then
                if r_por_count = "1111" then
                    s_por_done <= '1';
                else
                    r_por_count <= r_por_count + 1;
                end if;
            end if;
        end if;
    end process;

    -- ── Post-load reset stretch ─────────────────────────────────────────
    -- Hold the CPU in reset for 64 cycles after load_done rises, so the
    -- fast->slow clock mux switch happens while safely in reset.
    process(s_clk_load)
    begin
        if rising_edge(s_clk_load) then
            if load_done = '0' then
                r_run_count <= (others => '0');
                s_run_rdy   <= '0';
            elsif r_run_count = "111111" then
                s_run_rdy   <= '1';
            else
                r_run_count <= r_run_count + 1;
            end if;
        end if;
    end process;

    -- CPU runs only when: POR finished, program loaded (+64 cyc), SW0 down.
    s_rst <= (not s_por_done) or (not load_done) or (not s_run_rdy)
             or r_sw0_sync;

    -- SW1 up wipes the loader so a NEW program can be streamed in.
    s_loader_rst <= (not s_por_done) or r_sw1_sync;

    -- ── JTAG UART (Qsys system) ────────────────────────────────────────
    JTAG_UART_INST : wrapper
        port map (
            clk_clk                                   => s_clk_load,
            jtag_uart_0_clk_clk                       => s_clk_load,
            jtag_uart_0_reset_reset_n                 => s_por_done,
            reset_reset_n                             => s_por_done,
            jtag_uart_0_avalon_jtag_slave_chipselect  => '1',
            jtag_uart_0_avalon_jtag_slave_address     => '0',   -- DATA register
            jtag_uart_0_avalon_jtag_slave_read_n      => uart_read_n,
            jtag_uart_0_avalon_jtag_slave_write_n     => '1',
            jtag_uart_0_avalon_jtag_slave_writedata   => (others => '0'),
            jtag_uart_0_avalon_jtag_slave_readdata    => uart_readdata,
            jtag_uart_0_avalon_jtag_slave_waitrequest => uart_waitrequest,
            jtag_uart_0_irq_irq                       => open
        );

    -- ── Byte-read FSM: poll the data register, RVALID = bit 15 ─────────
    -- Avalon rule honored: av_read_n stays LOW until waitrequest drops.
    process(s_clk_load)
    begin
        if rising_edge(s_clk_load) then
            uart_valid <= '0';
            if s_por_done = '0' then
                uart_read_n <= '1';
                uart_state  <= IDLE;
            else
                case uart_state is
                    when IDLE =>
                        uart_read_n <= '0';          -- launch a read
                        uart_state  <= RD;
                    when RD =>
                        if uart_waitrequest = '0' then
                            uart_read_n <= '1';       -- read accepted
                            uart_byte   <= uart_readdata(7 downto 0);
                            uart_valid  <= uart_readdata(15);  -- RVALID
                            uart_state  <= IDLE;
                        end if;                       -- else: HOLD read_n low
                end case;
            end if;
        end if;
    end process;

    -- ── Loader FSM ─────────────────────────────────────────────────────
    LOADER : uart_loader
        port map (
            clk        => s_clk_load,
            rst        => s_loader_rst,
            uart_byte  => uart_byte,
            uart_valid => uart_valid,
            mem_we     => loader_we,
            mem_addr   => loader_addr,
            mem_data   => loader_data,
            word_count => word_count,
            load_done  => load_done
        );

    -- ── Processor ──────────────────────────────────────────────────────
    -- While loading, iCLK = s_clk_load (same clock as the loader), so the
    -- one-cycle loader_we pulse is sampled exactly once by IMem.
    MyProcessor : RISCV_Processor
        generic map (N => N)
        port map (
            iCLK      => s_clk_cpu,
            iRST      => s_rst,
            iInstLd   => loader_we,
            iInstAddr => loader_addr,
            iInstExt  => loader_data,
            oALUOut   => s_alu_out
        );

    -- ── Diagnostic event latches ────────────────────────────────────────
    process(s_clk_load)
    begin
        if rising_edge(s_clk_load) then
            if r_sw1_sync = '1' then             -- SW1 up clears the flags
                r_saw_rdack  <= '0';
                r_saw_rvalid <= '0';
                r_saw_we     <= '0';
                r_byte_cnt   <= (others => '0');
            else
                if uart_state = RD and uart_waitrequest = '0' then
                    r_saw_rdack <= '1';
                    if uart_readdata(15) = '1' then
                        r_saw_rvalid <= '1';
                    end if;
                end if;
                if uart_valid = '1' then
                    r_byte_cnt <= r_byte_cnt + 1;
                end if;
                if loader_we = '1' then
                    r_saw_we <= '1';
                end if;
            end if;
        end if;
    end process;

    -- ── Hold last non-zero ALU result ──────────────────────────────────
    process(s_clk_cpu)
    begin
        if rising_edge(s_clk_cpu) then
            if s_rst = '1' then
                s_disp_reg <= (others => '0');
            elsif unsigned(s_alu_out) /= 0 then
                s_disp_reg <= s_alu_out;
            end if;
        end if;
    end process;

    s_disp_mux <= s_alu_out when SW(16) = '0' else s_disp_reg;

    HEX0 <= to_seg7(s_disp_mux(3  downto 0));
    HEX1 <= to_seg7(s_disp_mux(7  downto 4));
    HEX2 <= to_seg7(s_disp_mux(11 downto 8));
    HEX3 <= to_seg7(s_disp_mux(15 downto 12));
    HEX4 <= to_seg7(s_disp_mux(19 downto 16));
    HEX5 <= to_seg7(s_disp_mux(23 downto 20));
    HEX6 <= to_seg7(s_disp_mux(27 downto 24));
    HEX7 <= to_seg7(s_disp_mux(31 downto 28));

    -- ── Debug LEDs ─────────────────────────────────────────────────────
    -- While loading: LEDR[9:0] = words written, LEDR[17:10] = raw bytes seen.
    -- A single keystroke moves LEDR[17:10] even before a full word forms.
    LEDR <= (std_logic_vector(r_byte_cnt) & word_count) when load_done = '0'
            else s_alu_out(17 downto 0);

    LEDG(0)          <= s_rst;
    LEDG(1)          <= s_por_done;
    LEDG(2)          <= s_clk_cpu;
    LEDG(3)          <= load_done;
    LEDG(4)          <= r_saw_rdack;   -- Avalon read completed at least once
    LEDG(5)          <= r_saw_rvalid;  -- at least one byte pulled from FIFO
    LEDG(6)          <= r_saw_we;      -- at least one word written to IMem
    LEDG(7)          <= '0';
    LEDG(8)          <= s_alu_out(0) or s_alu_out(1) or s_alu_out(2) or s_alu_out(3)
                        or s_alu_out(4) or s_alu_out(5) or s_alu_out(6) or s_alu_out(7);

end architecture structural;
