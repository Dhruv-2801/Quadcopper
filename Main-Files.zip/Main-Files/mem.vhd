-- mem.vhd

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity mem is
    generic (
        DATA_WIDTH : natural := 32;
        ADDR_WIDTH : natural := 10;
        INIT_FILE  : string  := "UNUSED"   -- "UNUSED" = no preload (DMem)
    );
    port (
        clk  : in  std_logic;
        addr : in  std_logic_vector((ADDR_WIDTH-1) downto 0);
        data : in  std_logic_vector((DATA_WIDTH-1) downto 0);
        we   : in  std_logic := '0';       -- default OFF (safer than '1')
        q    : out std_logic_vector((DATA_WIDTH-1) downto 0)
    );
end mem;

architecture rtl of mem is

    subtype word_t   is std_logic_vector((DATA_WIDTH-1) downto 0);
    type    memory_t is array(2**ADDR_WIDTH-1 downto 0) of word_t;

    signal ram : memory_t;

    -- Quartus synthesis attribute: preload this RAM from a MIF at compile time.
    attribute ram_init_file : string;
    attribute ram_init_file of ram : signal is INIT_FILE;

begin

    -- Falling-edge write + registered read.
    -- Note q reads the OLD value on a same-address write (VHDL signal
    -- semantics), which matches the M9K's supported read-during-write mode.
    process(clk)
    begin
        if falling_edge(clk) then
            if we = '1' then
                ram(to_integer(unsigned(addr))) <= data;
            end if;
            q <= ram(to_integer(unsigned(addr)));
        end if;
    end process;

end rtl;
